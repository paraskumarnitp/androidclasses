package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
TextView t1,t2;
EditText edit1,edit2;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

      edit1=findViewById(R.id.username);
      edit2=findViewById(R.id.password);

    }
public void register(View  view)
{
    Intent intent = new Intent(MainActivity.this, Registration.class);
    startActivity(intent);
}

public void loginMe(View vi)
{
    String uname,pwd;
    uname= edit1.getText().toString();
    pwd=edit2.getText().toString();

    if(uname.equals("pwc") && pwd.equals("123"))
    {

        Intent intent = new Intent(MainActivity.this, Registration.class);
        intent.putExtra("username",uname);

        startActivity(intent);
        //Toast.makeText(this,"user name and password correct",Toast.LENGTH_LONG).show();
    }
    else {
        Toast.makeText(this,"user name and password incorrect",Toast.LENGTH_LONG).show();
    }
}

}