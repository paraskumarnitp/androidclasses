package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Registration extends AppCompatActivity {
EditText et1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        et1=findViewById(R.id.username);
        Intent intent=getIntent();
        String uname=intent.getStringExtra("username");
        et1.setText(uname);


    }
    public void login(View view)
    {
        Intent intent = new Intent(Registration.this,MainActivity.class);
        startActivity(intent);

    }
}