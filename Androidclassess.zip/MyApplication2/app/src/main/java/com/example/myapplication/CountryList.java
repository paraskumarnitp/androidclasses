package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

public class CountryList extends AppCompatActivity {

    ListView simpleList;
    String countryList[] = {"India", "China", "australia", "Portugle", "America", "NewZealand"};
    int flags[] = {R.drawable.burger, R.drawable.cake, R.drawable.fries, R.drawable.pwclogo, R.drawable.loginbkg, R.drawable.pwclogo};
    String capitalList[] = {"Delhi", "Biging", "Sidiny", "Portugle", "Wasingoton", "NewZealand"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_country_list);
        simpleList = findViewById(R.id.simpleListView);

        CustomAdapter customAdapter = new CustomAdapter(getApplicationContext(), countryList, flags,capitalList);
        simpleList.setAdapter(customAdapter);
    }
}